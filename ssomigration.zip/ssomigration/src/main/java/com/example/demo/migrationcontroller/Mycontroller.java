package com.example.demo.migrationcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.ssomigration.service.OtpService;

@RestController
@RequestMapping("/otp")
public class Mycontroller {
	  @Autowired
	    private OtpService otpService;

	    @PostMapping("/generate")
	    public String generateOtp(@RequestParam String email) {
	        otpService.generateOtp(email);
	        return "OTP sent to your email";
	    }

	    @PostMapping("/validate")
	    public boolean validateOtp(@RequestParam String email, @RequestParam String otp) {
	        return otpService.validateOtp(email, otp);
	    }
	    
	    @GetMapping("/")
	    public String getpage() {
	    	return "index";
	    	
	    }
	  
}
