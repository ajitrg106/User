/*
 * package com.example.demo.ssomigration.repository;
 * 
 * import java.util.Optional;
 * 
 * import org.springframework.data.jpa.repository.JpaRepository;
 * 
 * import com.example.demo.migration.model.MemberMigrationTracker;
 * 
 * public interface MemberMigrationTrackerRepository extends
 * JpaRepository<MemberMigrationTracker, Long> {
 * Optional<MemberMigrationTracker> findByEmail(); }
 */