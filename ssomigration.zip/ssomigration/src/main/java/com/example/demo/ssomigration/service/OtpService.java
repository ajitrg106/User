package com.example.demo.ssomigration.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.migrationcontroller.Otp;
import com.example.demo.migrationcontroller.OtpGenerator;
import com.example.demo.ssomigration.repository.OtpRepository;
@Service
public class OtpService {
	private static final int OTP_VALIDITY_MINUTES = 1;

	@Autowired
	private OtpRepository otpRepository;

	public Otp generateOtp(String email) {
		String otp = OtpGenerator.generateOtp();
		Otp otpEntity = new Otp();
		otpEntity.setEmail(email);
		otpEntity.setOtp(otp);
		otpEntity.setExpiryTime(LocalDateTime.now().plusMinutes(OTP_VALIDITY_MINUTES));
		return otpRepository.save(otpEntity);
	}

	public boolean validateOtp(String email, String otp) {
		Optional<Otp> otpEntityOptional = otpRepository.findByEmailAndOtp(email, otp);
		if (otpEntityOptional.isPresent()) {
			Otp otpEntity = otpEntityOptional.get();
			return otpEntity.getExpiryTime().isAfter(LocalDateTime.now());
		}
		return false;
	}

}
